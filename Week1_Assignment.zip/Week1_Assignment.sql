-- 1. List of all customers
USE AdventureWorks2019;
GO
SELECT CustomerID, PersonID, StoreID, TerritoryID FROM Sales.Customer;

-- 2. Customers where the store name ends with 'N'
SELECT c.CustomerID, s.Name AS StoreName
FROM Sales.Customer c
INNER JOIN Sales.Store s ON c.StoreID = s.BusinessEntityID
WHERE s.Name LIKE '%N';

-- 3. Customers living in Berlin or London
SELECT p.FirstName, p.LastName, a.City
FROM Person.Person p
JOIN Person.BusinessEntityAddress ba ON p.BusinessEntityID = ba.BusinessEntityID
JOIN Person.Address a ON ba.AddressID = a.AddressID
WHERE a.City IN ('Berlin', 'London');

-- 4. Customers living in UK or USA
SELECT p.FirstName, p.LastName, cr.Name AS Country
FROM Person.Person p
JOIN Person.BusinessEntityAddress ba ON p.BusinessEntityID = ba.BusinessEntityID
JOIN Person.Address a ON ba.AddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
JOIN Person.CountryRegion cr ON sp.CountryRegionCode = cr.CountryRegionCode
WHERE cr.CountryRegionCode IN ('GB', 'US');

-- 5. List all products sorted by product name
SELECT Name FROM Production.Product ORDER BY Name;

-- 6. List products starting with 'A'
SELECT Name FROM Production.Product WHERE Name LIKE 'A%';

-- 7. Customers who placed at least one order
SELECT DISTINCT c.CustomerID
FROM Sales.Customer c
JOIN Sales.SalesOrderHeader o ON c.CustomerID = o.CustomerID;

-- 8. Customers living in London who bought product containing 'chai'
SELECT DISTINCT p.FirstName, p.LastName
FROM Sales.Customer c
JOIN Person.Person p ON c.PersonID = p.BusinessEntityID
JOIN Sales.SalesOrderHeader o ON c.CustomerID = o.CustomerID
JOIN Sales.SalesOrderDetail d ON o.SalesOrderID = d.SalesOrderID
JOIN Production.Product pr ON d.ProductID = pr.ProductID
JOIN Person.BusinessEntityAddress ba ON p.BusinessEntityID = ba.BusinessEntityID
JOIN Person.Address a ON ba.AddressID = a.AddressID
WHERE a.City = 'London' AND pr.Name LIKE '%chai%';

-- 9. Customers who never placed any order
SELECT CustomerID FROM Sales.Customer
WHERE CustomerID NOT IN (SELECT CustomerID FROM Sales.SalesOrderHeader);

-- 10. Customers who ordered 'Tofu'
SELECT DISTINCT c.CustomerID
FROM Sales.Customer c
JOIN Sales.SalesOrderHeader o ON c.CustomerID = o.CustomerID
JOIN Sales.SalesOrderDetail d ON o.SalesOrderID = d.SalesOrderID
JOIN Production.Product p ON d.ProductID = p.ProductID
WHERE p.Name = 'Tofu';

-- 11. Details of the first (earliest) order
SELECT TOP 1 * FROM Sales.SalesOrderHeader ORDER BY OrderDate ASC;

-- 12. Details of the most expensive order date
SELECT TOP 1 OrderDate, TotalDue FROM Sales.SalesOrderHeader ORDER BY TotalDue DESC;

-- 13. For each order: OrderID and average quantity of items
SELECT SalesOrderID, AVG(OrderQty) AS AverageQuantity
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID;

-- 14. For each order: OrderID, minimum quantity, and maximum quantity
SELECT SalesOrderID, MIN(OrderQty) AS MinimumQuantity, MAX(OrderQty) AS MaximumQuantity
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID;

-- 15. Managers and total number of employees reporting to them
SELECT Manager.BusinessEntityID AS ManagerID, COUNT(e.BusinessEntityID) AS ReportCount
FROM HumanResources.Employee e
JOIN HumanResources.Employee Manager ON e.OrganizationNode.GetAncestor(1) = Manager.OrganizationNode
GROUP BY Manager.BusinessEntityID;

-- 16. Orders with total quantity greater than 300
SELECT SalesOrderID, SUM(OrderQty) AS TotalQuantity
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID
HAVING SUM(OrderQty) > 300;

-- 17. Orders placed on or after 1996-12-31
SELECT * FROM Sales.SalesOrderHeader WHERE OrderDate >= '1996-12-31';

-- 18. Orders shipped to Canada
SELECT o.SalesOrderID
FROM Sales.SalesOrderHeader o
JOIN Person.Address a ON o.ShipToAddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
JOIN Person.CountryRegion cr ON sp.CountryRegionCode = cr.CountryRegionCode
WHERE cr.Name = 'Canada';

-- 19. Orders with total order amount greater than 200
SELECT SalesOrderID, TotalDue FROM Sales.SalesOrderHeader WHERE TotalDue > 200;

-- 20. Total sales per country
SELECT cr.Name AS Country, SUM(o.TotalDue) AS TotalSales
FROM Sales.SalesOrderHeader o
JOIN Person.Address a ON o.ShipToAddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
JOIN Person.CountryRegion cr ON sp.CountryRegionCode = cr.CountryRegionCode
GROUP BY cr.Name;

-- 21. Customer full name and number of orders they placed
SELECT p.FirstName + ' ' + p.LastName AS CustomerName, COUNT(o.SalesOrderID) AS NumberOfOrders
FROM Sales.Customer c
JOIN Person.Person p ON c.PersonID = p.BusinessEntityID
JOIN Sales.SalesOrderHeader o ON c.CustomerID = o.CustomerID
GROUP BY p.FirstName, p.LastName;

-- 22. Customers with more than 3 orders
SELECT p.FirstName + ' ' + p.LastName AS CustomerName, COUNT(o.SalesOrderID) AS OrderCount
FROM Sales.Customer c
JOIN Person.Person p ON c.PersonID = p.BusinessEntityID
JOIN Sales.SalesOrderHeader o ON c.CustomerID = o.CustomerID
GROUP BY p.FirstName, p.LastName
HAVING COUNT(o.SalesOrderID) > 3;

-- 23. Discontinued products ordered between 1997-01-01 and 1998-01-01
SELECT DISTINCT p.ProductID, p.Name
FROM Production.Product p
JOIN Sales.SalesOrderDetail d ON p.ProductID = d.ProductID
JOIN Sales.SalesOrderHeader o ON d.SalesOrderID = o.SalesOrderID
WHERE p.SellEndDate IS NOT NULL
  AND o.OrderDate BETWEEN '1997-01-01' AND '1998-01-01';

-- 24. Employees with their supervisors' names
SELECT e.BusinessEntityID, ep.FirstName AS EmployeeFirstName, ep.LastName AS EmployeeLastName,
       sp.FirstName AS SupervisorFirstName, sp.LastName AS SupervisorLastName
FROM HumanResources.Employee e
JOIN HumanResources.Employee s ON e.OrganizationNode.GetAncestor(1) = s.OrganizationNode
JOIN Person.Person ep ON e.BusinessEntityID = ep.BusinessEntityID
JOIN Person.Person sp ON s.BusinessEntityID = sp.BusinessEntityID;

-- 25. Employees and total sales they made
SELECT SalesPersonID, SUM(TotalDue) AS TotalSales
FROM Sales.SalesOrderHeader
WHERE SalesPersonID IS NOT NULL
GROUP BY SalesPersonID;

-- 26. Employees whose first name contains 'a'
SELECT FirstName, LastName FROM Person.Person WHERE FirstName LIKE '%a%';

-- 27. Managers with more than 4 employees reporting to them
SELECT Manager.BusinessEntityID AS ManagerID, COUNT(e.BusinessEntityID) AS NumberOfReports
FROM HumanResources.Employee e
JOIN HumanResources.Employee Manager ON e.OrganizationNode.GetAncestor(1) = Manager.OrganizationNode
GROUP BY Manager.BusinessEntityID
HAVING COUNT(e.BusinessEntityID) > 4;

-- 28. Orders with product names
SELECT d.SalesOrderID, p.Name AS ProductName
FROM Sales.SalesOrderDetail d
JOIN Production.Product p ON d.ProductID = p.ProductID;

-- 29. Orders placed by the customer with most orders
WITH CustomerOrderCounts AS (
  SELECT CustomerID, COUNT(*) AS OrderCount FROM Sales.SalesOrderHeader GROUP BY CustomerID
)
SELECT o.SalesOrderID
FROM Sales.SalesOrderHeader o
WHERE o.CustomerID = (SELECT TOP 1 CustomerID FROM CustomerOrderCounts ORDER BY OrderCount DESC);

-- 30. Orders placed by customers without a fax number
SELECT o.SalesOrderID
FROM Sales.SalesOrderHeader o
JOIN Sales.Customer c ON o.CustomerID = c.CustomerID
WHERE c.CustomerID NOT IN (
  SELECT BusinessEntityID FROM Person.PersonPhone WHERE PhoneNumberTypeID = 3
);

-- 31. Postal codes where product 'Tofu' was shipped
SELECT DISTINCT a.PostalCode
FROM Sales.SalesOrderHeader o
JOIN Sales.SalesOrderDetail d ON o.SalesOrderID = d.SalesOrderID
JOIN Production.Product p ON d.ProductID = p.ProductID
JOIN Person.Address a ON o.ShipToAddressID = a.AddressID
WHERE p.Name = 'Tofu';

-- 32. Products shipped to France
SELECT DISTINCT p.Name
FROM Sales.SalesOrderHeader o
JOIN Sales.SalesOrderDetail d ON o.SalesOrderID = d.SalesOrderID
JOIN Production.Product p ON d.ProductID = p.ProductID
JOIN Person.Address a ON o.ShipToAddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
JOIN Person.CountryRegion cr ON sp.CountryRegionCode = cr.CountryRegionCode
WHERE cr.Name = 'France';

-- 33. Product names and categories for supplier 'Specialty Biscuits, Ltd.'
SELECT p.Name AS ProductName, c.Name AS CategoryName
FROM Production.Product p
JOIN Production.ProductSubcategory ps ON p.ProductSubcategoryID = ps.ProductSubcategoryID
JOIN Production.ProductCategory c ON ps.ProductCategoryID = c.ProductCategoryID
JOIN Purchasing.ProductVendor pv ON p.ProductID = pv.ProductID
JOIN Purchasing.Vendor v ON pv.BusinessEntityID = v.BusinessEntityID
WHERE v.Name = 'Specialty Biscuits, Ltd.';

-- 34. Products never ordered
SELECT Name FROM Production.Product
WHERE ProductID NOT IN (SELECT DISTINCT ProductID FROM Sales.SalesOrderDetail);

-- 35. Products with stock less than 10 and reorder point zero
SELECT Name FROM Production.Product
WHERE SafetyStockLevel < 10 AND ReorderPoint = 0;

-- 36. Top 10 countries by sales amount
SELECT TOP 10 cr.Name AS Country, SUM(o.TotalDue) AS TotalSales
FROM Sales.SalesOrderHeader o
JOIN Person.Address a ON o.ShipToAddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
JOIN Person.CountryRegion cr ON sp.CountryRegionCode = cr.CountryRegionCode
GROUP BY cr.Name
ORDER BY TotalSales DESC;

-- 37. Number of orders handled by employees for customers with AccountNumber between 'A' and 'AO'
SELECT e.BusinessEntityID, COUNT(o.SalesOrderID) AS OrderCount
FROM Sales.SalesOrderHeader o
JOIN Sales.Customer c ON o.CustomerID = c.CustomerID
JOIN HumanResources.Employee e ON o.SalesPersonID = e.BusinessEntityID
WHERE c.AccountNumber BETWEEN 'A' AND 'AO'
GROUP BY e.BusinessEntityID;

-- 38. Date of the most expensive order
SELECT TOP 1 OrderDate FROM Sales.SalesOrderHeader ORDER BY TotalDue DESC;

-- 39. Product names with total revenue
SELECT p.Name, SUM(d.LineTotal) AS Revenue
FROM Sales.SalesOrderDetail d
JOIN Production.Product p ON d.ProductID = p.ProductID
GROUP BY p.Name;

-- 40. Suppliers and number of products they offer
SELECT BusinessEntityID AS SupplierID, COUNT(ProductID) AS ProductCount
FROM Purchasing.ProductVendor
GROUP BY BusinessEntityID;

-- 41. Top 10 customers by number of orders placed
WITH CustomerOrderCounts AS (
  SELECT CustomerID, COUNT(*) AS OrderCount FROM Sales.SalesOrderHeader GROUP BY CustomerID
)
SELECT TOP 10 c.CustomerID, p.FirstName + ' ' + p.LastName AS CustomerName, OrderCount
FROM CustomerOrderCounts c
JOIN Sales.Customer cu ON c.CustomerID = cu.CustomerID
JOIN Person.Person p ON cu.PersonID = p.BusinessEntityID
ORDER BY OrderCount DESC;

-- 42. Total revenue from all sales
SELECT SUM(TotalDue) AS TotalRevenue FROM Sales.SalesOrderHeader;
